﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.tools
{
    class Class1
    {   
    /// <summary>
    /// Метод вывода массива
    /// </summary>
    /// <param name="n">Исходный массив</param>
        internal static void OutArr(int[] n)
        {
            int d = 0;
            while (d< n.Length)
            {
                Console.WriteLine(n[d]);
                d++;
            }

            //foreach (int k in n)
            //    Console.WriteLine(k);
        }

 
    }
}
